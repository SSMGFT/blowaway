class Animal:
    def __init__(self, Animal) -> None:
        print(Animal, ' is an Animal.')

class Mammal(Animal):
    def __init__(self, MammalName) -> None:
        print(MammalName, ' is a warm blooded Animal.')
        super().__init__(MammalName)

class NonWingedMammal(Mammal):
    def __init__(self, NonWingedMammalName) -> None:
        print(NonWingedMammalName , ' cannot fly.')
        super().__init__(NonWingedMammalName)

class NonMarineMammal(Mammal):
    def __init__(self, NonMarineMammalName) -> None:
        print(NonMarineMammalName, ' cannot swim')
        super().__init__(NonMarineMammalName)

class dog(NonMarineMammal,NonWingedMammal):
    def __init__(self) -> None:
        print('Dog has 4 legs.')
        super().__init__('Dog')


d=dog()
bat= NonMarineMammal('Bat')