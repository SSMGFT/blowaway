import sys 
import warnings
import rpyc


conn = rpyc.connect('localhost',9011)
print('name =', __name__)
print('file =', __file__)
checkmate= conn.root.logsaveService

print('1rook runs')

stdout=checkmate(scriptname=__name__,filename=__file__,initial_value=None,newline=None)
sys.stdout=stdout
stderr=checkmate(scriptname=__name__,filename=__file__,initial_value=None,newline=None)
sys.stderr=stderr

print('2queen misses',flush=True) 
print('3queen misses again')
warnings.warn('fake warning')
a,b=0,3
print('6queen misses again')
print(b/a)