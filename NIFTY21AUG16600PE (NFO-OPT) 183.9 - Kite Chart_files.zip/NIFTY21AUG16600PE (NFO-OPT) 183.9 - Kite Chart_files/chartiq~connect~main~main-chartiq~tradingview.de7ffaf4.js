(window["webpackJsonp"] = window["webpackJsonp"] || []).push([
    ["chartiq~connect~main~main-chartiq~tradingview"], {
        "0e50": function (t, e, r) {
            "use strict";
            var s = r("3da7"),
                n = r("d9d2"),
                i = r("025e"),
                a = r("b202");

            function o(t) {
                let e = [],
                    r = [];
                for (let s of t) - 1 !== s.status.indexOf("COMPLETE") || -1 !== s.status.indexOf("REJECT") || -1 !== s.status.indexOf("CANCEL") || -1 !== s.status.indexOf("LAPSED") ? r.push(s) : e.push(s);
                return {
                    pendingOrders: e,
                    completedOrders: r
                }
            }
            r.d(e, "b", (function () {
                return u
            }));
            let l = !0;
            const u = n["a"],
                c = {
                    orders: null,
                    ordersError: null,
                    pendingOrders: null,
                    completedOrders: null,
                    orderPrefs: Object(a["b"])(u, "orderPref") || {},
                    trades: null,
                    tradesError: null,
                    orderFetchStatus: 0,
                    tradeFetchStatus: 0,
                    gtt: null,
                    gttError: null,
                    gttFetchStatus: 0,
                    ordersNotificationCount: parseInt(Object(a["b"])(u, "ordersNotificationCount") || 0)
                },
                h = {
                    orders: t => t.orders,
                    ordersError: t => t.ordersError,
                    pendingOrders: t => t.pendingOrders,
                    completedOrders: t => t.completedOrders,
                    orderPrefs: t => t.orderPrefs,
                    ordersNotificationCount: t => t.ordersNotificationCount,
                    trades: t => t.trades,
                    tradesError: t => t.tradesError,
                    orderFetchStatus: t => t.orderFetchStatus,
                    tradeFetchStatus: t => t.tradeFetchStatus,
                    gtt: t => t.gtt,
                    gttError: t => t.gttError,
                    gttFetchStatus: t => t.gttFetchStatus
                },
                d = {
                    setOrders(t, e) {
                        t.orders = e;
                        let {
                            pendingOrders: r,
                            completedOrders: s
                        } = o(e);
                        t.pendingOrders = r, t.completedOrders = s
                    },
                    setOrdersError(t, e) {
                        t.ordersError = e
                    },
                    setOrderPrefs(t, e) {
                        t.orderPrefs = e, Object(a["d"])(u, "orderPref", e, null, Object(i["i"])())
                    },
                    setTrades(t, e) {
                        t.trades = e
                    },
                    setTradesError(t, e) {
                        t.tradesError = e
                    },
                    setOrderFetchStatus(t, e) {
                        t.orderFetchStatus = e
                    },
                    setTradeFetchStatus(t, e) {
                        t.tradeFetchStatus = e
                    },
                    setGTT(t, e) {
                        t.gtt = e
                    },
                    setGTTError(t, e) {
                        t.gttError = e
                    },
                    setGTTFetchStatus(t, e) {
                        t.gttFetchStatus = e
                    },
                    setOrderNotificationsCount(t, e) {
                        t.ordersNotificationCount = e, Object(a["d"])(u, "ordersNotificationCount", t.ordersNotificationCount, null, Object(i["i"])())
                    },
                    incOrderNotificationsCount(t, e) {
                        t.ordersNotificationCount += e, Object(a["d"])(u, "ordersNotificationCount", t.ordersNotificationCount, null, Object(i["i"])())
                    }
                },
                m = {
                    fetchOrders({
                        commit: t,
                        state: e
                    }) {
                        t("setOrderFetchStatus", 1);
                        let r = s["a"].getOrders();
                        Object(i["f"])({
                            commit: t,
                            apiPromise: r,
                            data: "setOrders",
                            error: "setOrdersError",
                            status: "setOrderFetchStatus"
                        })
                    },
                    fetchTrades({
                        commit: t,
                        state: e
                    }) {
                        t("setTradeFetchStatus", 1);
                        let r = s["a"].getTrades();
                        Object(i["f"])({
                            commit: t,
                            apiPromise: r,
                            data: "setTrades",
                            error: "setTradesError",
                            status: "setTradeFetchStatus"
                        })
                    },
                    fetchGTT({
                        commit: t,
                        state: e
                    }) {
                        t("setGTTFetchStatus", 1);
                        let r = s["a"].getGTT();
                        Object(i["f"])({
                            commit: t,
                            apiPromise: r,
                            data: "setGTT",
                            error: "setGTTError",
                            status: "setGTTFetchStatus"
                        })
                    }
                };
            e["a"] = {
                state: c,
                getters: h,
                mutations: d,
                actions: m,
                namespaced: l
            }
        },
        "3da7": function (t, e, r) {
            "use strict";
            var s = r("ba6a"),
                n = r("5665");

            function i(t) {
                return t ? s["a"].get(Object(n["a"])("orders.info", {
                    orderId: t
                })) : s["a"].get(Object(n["a"])("orders.all"))
            }

            function a() {
                return s["a"].get(Object(n["a"])("trades.all"))
            }

            function o(t) {
                return s["a"].get(Object(n["a"])("orders.trades", {
                    orderId: t
                }))
            }

            function l(t) {
                return s["a"].post(Object(n["a"])("orders.place", {
                    variety: t.variety
                }), t)
            }

            function u(t, e) {
                return s["a"].put(Object(n["a"])("orders.modify", {
                    orderId: t,
                    variety: e.variety
                }), e)
            }

            function c(t, e) {
                return s["a"].delete(Object(n["a"])("orders.cancel", {
                    orderId: t,
                    variety: e.variety
                }), {
                    params: e
                })
            }

            function h(t, e) {
                return s["a"].get(Object(n["a"])("orders.triggerRange", {
                    transactionType: t
                }), {
                    params: e
                })
            }

            function d(t) {
                return s["a"].post(Object(n["a"])("gtt_orders.place"), t)
            }

            function m(t, e) {
                return s["a"].put(Object(n["a"])("gtt_orders.modify", {
                    orderId: t
                }), e)
            }

            function p(t, e) {
                return s["a"].delete(Object(n["a"])("gtt_orders.cancel", {
                    orderId: t
                }), {
                    params: e
                })
            }

            function g(t) {
                return t ? s["a"].get(Object(n["a"])("gtt_orders.info", {
                    orderId: t
                })) : s["a"].get(Object(n["a"])("gtt_orders.all"))
            }

            function f(t) {
                return s["a"].post(Object(n["a"])("nudge.orders"), t, {
                    headers: {
                        "Content-Type": "application/json"
                    }
                })
            }

            function y(t) {
                return s["a"].post(Object(n["a"])("margins.orders"), t, {
                    headers: {
                        "Content-Type": "application/json"
                    }
                })
            }
            e["a"] = {
                getOrders: i,
                getTrades: a,
                getOrderTrades: o,
                placeOrder: l,
                cancelOrder: c,
                modifyOrder: u,
                getTriggerRange: h,
                placeGTT: d,
                modifyGTT: m,
                deleteGTT: p,
                getGTT: g,
                checkOrdersNudge: f,
                fetchOrderMargins: y
            }
        },
        6825: function (t, e, r) {
            "use strict";
            var s = function () {
                    var t = this,
                        e = t.$createElement,
                        r = t._self._c || e;
                    return r("div", {
                        directives: [{
                            name: "click-outside",
                            rawName: "v-click-outside",
                            value: t.hide,
                            expression: "hide"
                        }, {
                            name: "on-escape",
                            rawName: "v-on-escape",
                            value: t.hide,
                            expression: "hide"
                        }],
                        staticClass: "context-menu",
                        attrs: {
                            id: "context-menu-" + t._uid
                        }
                    }, [r("div", {
                        staticClass: "context-menu-button-wrap",
                        on: {
                            click: function (e) {
                                return e.stopPropagation(), e.preventDefault(), t.handleButtonClick(e)
                            }
                        }
                    }, [t._t("button")], 2), t._v(" "), r("transition", {
                        attrs: {
                            name: "dropdown"
                        }
                    }, [t.showMenu ? r("ul", {
                        staticClass: "context-menu-list list-flat layer-2"
                    }, [t._t("menu")], 2) : t._e()])], 1)
                },
                n = [],
                i = {
                    name: "mobile-context-menu",
                    props: {
                        orientation: {
                            type: String,
                            default: "left"
                        },
                        marginTop: {
                            type: Number,
                            default: 8
                        },
                        parentSelector: String
                    },
                    data() {
                        return {
                            showMenu: !1
                        }
                    },
                    deactivated() {
                        this.hide(), this.$emit("delete")
                    },
                    methods: {
                        hide() {
                            this.showMenu && (this.showMenu = !1)
                        },
                        handleButtonClick(t) {
                            this.showMenu ? this.showMenu = !1 : (this.showMenu = !0, this.$nextTick(() => {
                                let t = 0;
                                if (this.parentSelector) {
                                    let e = document.querySelector(this.parentSelector);
                                    t = e && e.scrollTop
                                } else t = window.pageYOffset || document.documentElement.scrollTop;
                                let e, r = this.$el.querySelector(".context-menu-list"),
                                    s = r.getBoundingClientRect(),
                                    n = this.$el.querySelector(".context-menu-button").getBoundingClientRect(),
                                    i = 0;
                                s.height + s.top - t <= window.innerHeight ? (e = "bottom", i = n.top + n.height + this.marginTop) : (e = "top", i = n.top - s.height - this.marginTop), i >= 0 ? r.style.top = i + "px" : (r.style.top = "0px", e = null), "bottom" === e ? r.classList.add("position-bottom") : "top" === e && r.classList.add("position-top");
                                let a = 0;
                                "left" === this.orientation ? a = n.left + n.width - s.width : "right" === this.orientation && (a = n.left + n.width), r.style.left = e ? a + "px" : a - n.width + "px"
                            }))
                        }
                    }
                },
                a = i,
                o = r("2877"),
                l = Object(o["a"])(a, s, n, !1, null, null, null);
            e["a"] = l.exports
        },
        "714b": function (t, e, r) {
            "use strict";
            var s = function () {
                    var t = this,
                        e = t.$createElement,
                        r = t._self._c || e;
                    return r("transition", {
                        attrs: {
                            name: "modal"
                        }
                    }, [r("div", {
                        staticClass: "modal-mask"
                    }, [r("div", {
                        staticClass: "modal-wrapper"
                    }, [r("div", {
                        staticClass: "modal-container layer-2"
                    }, [r("div", {
                        staticClass: "modal-header"
                    }, [t._t("header")], 2), t._v(" "), r("div", {
                        staticClass: "modal-body"
                    }, [t._t("body")], 2), t._v(" "), r("div", {
                        staticClass: "modal-footer"
                    }, [t._t("footer")], 2)])])])])
                },
                n = [],
                i = r("2f62");

            function a(t, e) {
                var r = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var s = Object.getOwnPropertySymbols(t);
                    e && (s = s.filter((function (e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), r.push.apply(r, s)
                }
                return r
            }

            function o(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var r = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? a(Object(r), !0).forEach((function (e) {
                        l(t, e, r[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : a(Object(r)).forEach((function (e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e))
                    }))
                }
                return t
            }

            function l(t, e, r) {
                return e in t ? Object.defineProperty(t, e, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = r, t
            }
            var u = {
                    name: "modal",
                    props: {
                        closeOnClick: {
                            type: Boolean,
                            default: !0
                        },
                        zIndex: {
                            type: Number,
                            default: 15
                        }
                    },
                    computed: o({}, Object(i["c"])(["isMobile"])),
                    data() {
                        return {
                            keyboardShortcutEvents: [{
                                keys: ["27"],
                                cb: this.close,
                                stop: !0,
                                prevent: !0
                            }]
                        }
                    },
                    mounted() {
                        this.$nextTick(() => {
                            this.closeOnClick && window.addEventListener("mousedown", this.closeOnDocumentClick), this.$el.style.zIndex = this.zIndex, document.body.classList.add("modal-open")
                        })
                    },
                    beforeDestroy() {
                        window.removeEventListener("mousedown", this.closeOnDocumentClick)
                    },
                    methods: {
                        closeOnDocumentClick(t) {
                            t.target === this.$el.querySelector(".modal-wrapper") && this.close()
                        },
                        close() {
                            this.$emit("close"), document.body.classList.remove("modal-open")
                        }
                    }
                },
                c = u,
                h = r("2877"),
                d = Object(h["a"])(c, s, n, !1, null, null, null);
            e["a"] = d.exports
        },
        "808c": function (t, e, r) {
            "use strict";

            function s(t, e, r) {
                return e in t ? Object.defineProperty(t, e, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = r, t
            }
            class n {
                constructor() {
                    s(this, "regSymbol", RegExp(/(.+?)((-EQ)|([0-9]{2})(([A-Z]{3})|(([0-9OND])([0-9]{2})))(FUT|([0-9.]+)(CE|PE)(W.)?))/i)), s(this, "regWeeklyExpiry", RegExp(/([0-9]{2})(([A-Z]{3})|(([0-9OND])([0-9]{2})))/i)), this.maxResults = 25, this.lastResults = null, this.currentYear = (new Date).getFullYear(), this.weeklyMonthsMap = {
                        1: "JAN",
                        2: "FEB",
                        3: "MAR",
                        4: "APR",
                        5: "MAY",
                        6: "JUN",
                        7: "JUL",
                        8: "AUG",
                        9: "SEP",
                        O: "OCT",
                        N: "NOV",
                        D: "DEC"
                    }, this.strikePrecision = {
                        "BCD-OPT": 4
                    }, this.eventsInstruments = {}, this.defaultTickSize = {
                        "MCX-OPT": 1,
                        "MCX-FUT": 1,
                        MCX: 1
                    }
                }
                init(t) {
                    this.months = t.months, this.weeklyMonthsMap = t.weekly_months, this.segments = this.arrayToSet(t.segments), this.segmentsList = t.segments, this.equitySegments = this.arrayToSet(t.equity_segments), this.optionsSegments = this.arrayToSet(t.options_segments), this.futuresSegments = this.arrayToSet(t.futures_segments), this.exchangeSegments = this.arrayToSet(t.exchange_segments), this.tradeableSegments = this.arrayToSet(t.tradeable_segments), this.segmentsID = t.segments_id_map, this.segmentsAliases = t.segments_aliases, this.segmentsExchangeMap = t.segments_exchange_map, this.eventsInstruments = Object.assign({}, this.arrayToMap(t.events)), this.instrumentsMap = {}, this.instrumentsArray = {}, this.equitySymbolMap = [];
                    for (let e of t.equity_segments) this.buildEquitySymbolMap(e, t.instruments[e]);
                    for (let e of t.segments) t.instruments[e] && this.feed(e, t.instruments[e])
                }
                buildEquitySymbolMap(t, e) {
                    for (let r of e) {
                        let e = r[5] || r[1];
                        this.equitySymbolMap[e] || (this.equitySymbolMap[e] = []), this.equitySymbolMap[e].push([t, r[1]])
                    }
                }
                feed(t, e) {
                    this.instrumentsMap[t] = {}, this.instrumentsArray[t] = [], this.equitySegments.has(t) || "INDICES" === t ? this.loadEquity(t, e) : this.optionsSegments.has(t) ? this.loadOptions(t, e) : this.futuresSegments.has(t) ? this.loadFutures(t, e) : console.log("skip loading segment: ", t)
                }
                search(t, e) {
                    e || (e = this.maxResults);
                    let r = this.tokenize(t),
                        s = this.searchSegments(r),
                        n = this.subtract(r, s.matchedTokens),
                        i = this.rankSegments(s.results);
                    0 === i.length && (i = this.allSegements());
                    let a = this.searchSymbols(i, n, t, e);
                    if (a.length > 0) this.lastResults = a;
                    else if (this.lastResults) return this.lastResults;
                    return a
                }
                get(t, e, r) {
                    if (t = t.toUpperCase(), -1 !== t.indexOf("-EQ") && (t = t.split("-EQ")[0]), r && !e && (e = this.getSegment(t, r)), t && e && this.instrumentsMap[e]) {
                        let r = this.instrumentsMap[e][t];
                        if (r) {
                            let t = this.makeInstrument({
                                exchangeToken: r[0],
                                tradingsymbol: r[1],
                                segment: e,
                                exchange: this.segmentsExchangeMap[e],
                                tickSize: r[2],
                                lotSize: r[3],
                                company: r[4] || "",
                                isin: r[5] || ""
                            });
                            return t.isFound = !0, t
                        }
                    }
                    let s = this.makeInstrument({
                        exchangeToken: 0,
                        tradingsymbol: t,
                        segment: e || r,
                        exchange: r || e,
                        tickSize: this.defaultTickSize[r || e] || .05,
                        lotSize: 1,
                        company: "",
                        isin: ""
                    });
                    return s.isFound = !1, s
                }
                getSegment(t, e) {
                    if (this.exchangeSegments.has(e)) return e;
                    let r = this.regSymbol.exec(t);
                    return r ? "FUT" === r[10] ? e + "-FUT" : r[11] && r[12] ? e + "-OPT" : null : null
                }
                loadEquity(t, e) {
                    let r = [],
                        s = {},
                        n = -1,
                        i = -1,
                        a = -1;
                    for (let o of e) {
                        let t, e, l, u = o[1],
                            c = o[2];
                        t = -1 === n ? o[0] : n + o[0], n = t, o[3] ? (e = o[3], i = e) : e = i, o[4] ? (l = o[4], a = l) : l = a;
                        let h = [t, u, e, l, c, o[5]];
                        r.push(h), s[u] = h
                    }
                    this.instrumentsArray[t] = r, this.instrumentsMap[t] = s
                }
                loadOptions(t, e) {
                    let r = [],
                        s = {};
                    for (let n = 0; n < e.length; n++) {
                        let i = e[n],
                            a = i[0],
                            o = i[1],
                            l = i[2];
                        for (let e = 0; e < i[3].length; e++) {
                            let n = i[3][e][0],
                                u = i[3][e][1];
                            for (let e in u)
                                if (u.hasOwnProperty(e)) {
                                    let i = u[e],
                                        c = -1,
                                        h = -1;
                                    for (let u = 0; u < i.length; u++) {
                                        let d, m, p; - 1 === c && -1 === h ? (m = i[u][0], d = i[u][1]) : (m = c + i[u][0], d = Math.round(h * Math.pow(10, 9) + i[u][1] * Math.pow(10, 9)) / Math.pow(10, 9)), h = d, c = m, p = i[u][2] ? i[u][2] : l;
                                        let g = "";
                                        g = this.strikePrecision[t] ? a + n + parseFloat(d).toFixed(this.strikePrecision[t]) + e : a + n + d + e;
                                        let f = this.expandExpiryString(n),
                                            y = f !== n ? f : null,
                                            b = [m, g, o, p, y];
                                        r.push(b), s[b[1]] = b
                                    }
                                }
                        }
                    }
                    this.instrumentsArray[t] = r, this.instrumentsMap[t] = s
                }
                loadFutures(t, e) {
                    let r = [],
                        s = {};
                    for (let n = 0; n < e.length; n++) {
                        let t = e[n][0],
                            i = -1,
                            a = e[n][1],
                            o = e[n][2];
                        for (let l = 0; l < e[n][3].length; l++) {
                            let u, c, h;
                            h = -1 === i ? e[n][3][l][0] : i + e[n][3][l][0], i = h, u = e[n][3][l][1], c = e[n][3][l][2] ? e[n][3][l][2] : o;
                            let d = this.expandExpiryString(u),
                                m = d !== u ? d : null,
                                p = [h, t + u + "FUT", a, c, m];
                            r.push(p), s[p[1]] = p
                        }
                    }
                    this.instrumentsArray[t] = r, this.instrumentsMap[t] = s
                }
                searchSymbols(t, e, r, s) {
                    let n = [];
                    for (let i of this.segmentsList) {
                        if (!this.instrumentsArray[i]) continue;
                        let s = -1 !== t.indexOf(i);
                        for (let t = 0; t < this.instrumentsArray[i].length; t++) {
                            let a = 0,
                                o = !0;
                            if (this.instrumentsArray[i][t][1] === r.toUpperCase()) a = -100;
                            else if (s)
                                for (let r = 0; r < e.length; r++) {
                                    let s = this.instrumentsArray[i][t][1].indexOf(e[r]),
                                        n = -1;
                                    if (this.instrumentsArray[i][t][4] && this.instrumentsArray[i][t].length > 4 && (n = this.instrumentsArray[i][t][4].indexOf(e[r]), n >= 0 && (n += 1)), -1 === s && -1 === n) {
                                        o = !1;
                                        break
                                    }
                                    0 === s ? a -= 2 : n && (a -= 1)
                                } else o = !1;
                            o && n.push([i, this.instrumentsArray[i][t], a, n.length])
                        }
                    }
                    return this.formatResults(n, s)
                }
                formatResults(t, e) {
                    t.sort((function (t, e) {
                        return t[2] === e[2] ? t[3] - e[3] : t[2] < e[2] ? -1 : 1
                    })), t = t.slice(0, e);
                    let r = [];
                    for (let s = 0; s < t.length; s++) {
                        let e = t[s][1],
                            n = t[s][0];
                        r.push(this.makeInstrument({
                            exchangeToken: e[0],
                            tradingsymbol: e[1],
                            segment: n,
                            exchange: this.segmentsExchangeMap[n],
                            tickSize: e[2],
                            lotSize: e[3],
                            company: e[4] || "",
                            isin: e[5] || ""
                        }))
                    }
                    return r
                }
                allSegements() {
                    let t = [];
                    return this.segments.forEach(e => t.push(e)), t
                }
                rankSegments(t) {
                    let e = [],
                        r = [];
                    for (let a in t) t.hasOwnProperty(a) && (e.push(a), r.push(t[a]));
                    let s = [],
                        n = -1,
                        i = -1;
                    while (1) {
                        if (n = r.indexOf(Math.max.apply(Math, r)), -1 === n) break;
                        let t = r[n];
                        if (r[n] = 0, t < i) break;
                        i = t, s.push(e[n])
                    }
                    return s
                }
                searchSegments(t) {
                    let e = {},
                        r = [];
                    for (let s of this.segmentsList)
                        for (let n = 0; n < t.length; n++) - 1 !== this.segmentsAliases[s].indexOf(t[n]) && (r.push(t[n]), e.hasOwnProperty(s) || (e[s] = 0), e[s]++);
                    return {
                        results: e,
                        matchedTokens: this.unique(r)
                    }
                }
                tokenize(t) {
                    t = this.trim(t).toUpperCase(), t = this.trim(t.replace(/[^a-z0-9.\s&]/gi, " ")), t = t.replace(/[\s+]/gi, " ");
                    let e = t.split(" ");
                    return this.unique(e)
                }
                trim(t) {
                    return "undefined" === typeof String.prototype.trim ? t.replace(/^\s+|\s+$/gm, "") : t.trim()
                }
                unique(t) {
                    return t.sort().filter((function (e, r) {
                        return !r || e !== t[r - 1]
                    }))
                }
                subtract(t, e) {
                    let r = [];
                    for (let s = 0; s < t.length; s++) - 1 === e.indexOf(t[s]) && r.push(t[s]);
                    return r
                }
                arrayToSet(t) {
                    let e = new Set;
                    return t.forEach(t => e.add(t)), e
                }
                makeInstrument({
                    exchangeToken: t,
                    tradingsymbol: e,
                    segment: r,
                    exchange: s,
                    tickSize: n,
                    lotSize: i,
                    company: a,
                    isin: o,
                    ignoreRelated: l
                }) {
                    let u = this.parse(e, s);
                    if (u.segment = r, u.exchange = s, u.tickSize = n, u.lotSize = i, u.company = a, u.tradable = this.tradeableSegments.has(r), u.precision = "CDS" === s || "BCD" === s ? 4 : 2, u.fullName = this.getFullName(u), u.niceName = this.getNiceName(u), u.stockWidget = this.isStockWidget(u), u.exchangeToken = t, u.instrumentToken = (t << 8) + this.segmentsID[r], u.isin = o, u.related = [], !l) {
                        let t = this.equitySymbolMap[o || e];
                        if (t)
                            for (let e of t)
                                if (e[0] !== r) {
                                    let t = this.instrumentsMap[e[0]][e[1]];
                                    if (!t) break;
                                    u.related.push(this.makeInstrument({
                                        exchangeToken: t[0],
                                        tradingsymbol: t[1],
                                        segment: e[0],
                                        exchange: this.segmentsExchangeMap[e[0]],
                                        tickSize: t[2],
                                        lotSize: t[3],
                                        company: t[4] || "",
                                        isin: t[5] || "",
                                        ignoreRelated: !0
                                    }))
                                }
                    }
                    if (!a && u.related.length > 0)
                        for (let c of u.related)
                            if (c.company) {
                                u.company = c.company;
                                break
                            } return u.isEvent = ("NSE" === s || "BSE" === s || "INDICES" === s) && this.eventsInstruments[e], u.isWeekly = u.expiryWeek > 0, u
                }
                getFullName(t) {
                    return "BSE" === t.exchange ? t.symbol + " (" + t.tradingsymbol + ")" : t.tradingsymbol
                }
                getNiceName(t) {
                    if ("EQ" === t.type) return t.tradingsymbol;
                    let e = t.symbol;
                    return t.expiryDay && (e += " " + t.expiryDay + this.dateSuffix(t.expiryDay)), t.expiryMonth && t.expiryYear && (e += " " + (t.expiryYear !== this.currentYear ? t.expiryYear.toString().substr(2, 4) : "") + this.months[t.expiryMonth - 1]), "OPT" === t.type ? e += " " + t.strike + " " + t.optionType : "FUT" === t.type && (e += " " + t.type), e
                }
                isStockWidget(t) {
                    return this.equitySegments.has(t.exchange)
                }
                IsEquity(t) {
                    return this.equitySegments.has(t) || "INDICES" === t
                }
                extractEqSymbol(t) {
                    return t.length > 3 && "-" === t[t.length - 3] ? t.slice(0, -3) : t
                }
                parse(t, e) {
                    let r = "";
                    if (-1 !== t.indexOf("|") && "BSE" === e) {
                        var s = t.split("|");
                        t = s[0], r = s[1]
                    }
                    let n = {};
                    n.tradingsymbol = t, n.scripCode = r;
                    let i = this.regSymbol.exec(t);
                    if (!i) return n.type = "EQ", n.symbol = this.extractEqSymbol(t), n;
                    if (n.symbol = i[1], "-EQ" === i[2] && (n.type = "EQ"), "FUT" === i[10] ? n.type = "FUT" : i[11] && i[12] && (n.type = "OPT", n.optionType = i[12], n.strike = parseFloat(i[11])), i[4] && i[8] && i[9] && this.weeklyMonthsMap[i[8]]) {
                        let t = this.weeklyMonthsMap[i[8]];
                        n.expiryMonth = this.months.indexOf(t.toUpperCase()) + 1, n.expiryYear = parseInt(i[4]) + 2e3, n.expiryDay = parseInt(i[9]), n.expiryWeek = Math.floor(parseInt(i[9]) / 7) + 1
                    } else i[4] && i[5] && (n.expiryYear = parseInt(i[4]) + 2e3, n.expiryMonth = this.months.indexOf(i[5].toUpperCase()) + 1);
                    return n
                }
                expandExpiryString(t) {
                    const e = this.regWeeklyExpiry.exec(t);
                    return e && e[5] && e[6] ? e[6] + " " + this.weeklyMonthsMap[e[5]] + " WEEKLY" : t
                }
                dateSuffix(t) {
                    if (t > 3 && t < 21) return "th";
                    switch (t % 10) {
                        case 1:
                            return "st";
                        case 2:
                            return "nd";
                        case 3:
                            return "rd";
                        default:
                            return "th"
                    }
                }
                arrayToMap(t, e) {
                    if (!t) return {};
                    e || (e = "");
                    let r = {};
                    for (let s of t) r[e + s] = !0;
                    return r
                }
            }
            var i = n;
            r.d(e, "a", (function () {
                return a
            }));
            class a {}
            a.InstrumentManager = i, a.install = function (t, e) {}
        },
        aada: function (t, e, r) {
            "use strict";
            var s = function () {
                    var t = this,
                        e = t.$createElement,
                        r = t._self._c || e;
                    return r("div", {
                        staticClass: "empty-state"
                    }, [t._t("header"), t._v(" "), t.image ? r("img", {
                        staticClass: "empty-img",
                        attrs: {
                            src: t.image
                        }
                    }) : t._e(), t._v(" "), t._t("message"), t._v(" "), t.showOmnisearch ? r("su-button", {
                        class: t.omnisearchClass,
                        nativeOn: {
                            click: function (e) {
                                return e.preventDefault(), e.stopPropagation(), t.showMarketDepthWidget(e)
                            }
                        }
                    }, [t._v(t._s(t.omnisearchActionTitle))]) : t._e(), t._v(" "), t._t("action"), t._v(" "), t._t("footer")], 2)
                },
                n = [],
                i = r("5fb0"),
                a = {
                    name: "empty-state",
                    props: {
                        image: String,
                        showOmnisearch: Boolean,
                        omnisearchActionTitle: {
                            type: String,
                            default: "Get started"
                        },
                        omnisearchClass: {
                            type: String,
                            default: "button-blue"
                        }
                    },
                    data() {
                        return {}
                    },
                    methods: {
                        showMarketDepthWidget() {
                            this.$events.emit(i["c"].EVENTS.showMarketDepthWidget)
                        }
                    }
                },
                o = a,
                l = r("2877"),
                u = Object(l["a"])(o, s, n, !1, null, null, null);
            e["a"] = u.exports
        },
        da42: function (t, e, r) {
            "use strict";
            r.d(e, "a", (function () {
                return a
            }));
            var s = r("3da7"),
                n = r("0e50"),
                i = r("d9d2");
            class a {}
            a.api = s["a"], a.constants = i["b"], a.events = i["b"].EVENTS, a.namespace = i["b"].NAMESPACE, a.install = function (t, e) {
                e.store && e.store.registerModule(i["b"].NAMESPACE, n["a"])
            }
        }
    }
]);