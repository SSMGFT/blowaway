from io import StringIO
from typing import Optional
import sys 
import warnings
from datetime import datetime
from pymongo import MongoClient, InsertOne
import rpyc
from rpyc.utils.server import ThreadedServer
connection = MongoClient('mongodb://admin:password@127.0.0.1:27017')['protologging']['delete_me']

print('name =', __name__)
print('file =', __file__)

class logsaveService(rpyc.Service):
    def on_connect(self, conn):
        print('someone connected')
    def on_disconnect(self, conn):
        print('someone disconnected')

    class exposed_checkmate(StringIO):
        def __init__(self,scriptname,filename, initial_value: Optional[str], newline: Optional[str]) -> None:
            self.bufferstr=''
            self.scriptname=scriptname
            self.filename=filename
            print('new instance created')
            super().__init__(initial_value=initial_value, newline=newline)

        def exposed_write(self, __s: str) -> int:
            self.bufferstr=self.bufferstr+__s
            return super().write(__s)

        def exposed_flush(self) -> None:
            if self.bufferstr != '':
                record={'timestamp':datetime.now(),
                'module':self.scriptname,
                'file':self.filename,
                'message':self.bufferstr
                }
                g=connection.insert_one(record)
                self.bufferstr=''
            return super().flush()

if __name__ == '__main__':
    server = ThreadedServer(logsaveService,port = 9011)
    server.start()