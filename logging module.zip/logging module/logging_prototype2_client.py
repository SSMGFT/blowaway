import sys 
import warnings
import rpyc 
def printer(__s):
    print(__s,flush=True)

conn = rpyc.connect('localhost',9011)
print('name =', __name__)
print('file =', __file__)
checkmate= conn.root.checkmate

# print('1rook runs')

stdout=checkmate(scriptname=__name__,filename=__file__,initial_value=None,newline=None)
sys.stdout=stdout
stderr=checkmate(scriptname=__name__,filename=__file__,initial_value=None,newline=None)
sys.stderr=stderr

printer('2queen misses') 
printer('3queen misses again')
warnings.warn('fake warning')
a,b=0,3
printer('6queen misses again')
printer(b/a)