from io import StringIO
from typing import Optional
import sys 
import warnings

fileout = open('writestdout.txt','w')
fileerr = open('writestderr.txt','w')
print('name =', __name__)
print('file =', __file__)


class checkmate(StringIO):
    def __init__(self,fileobj, initial_value: Optional[str], newline: Optional[str]) -> None:
        self.fileobj=fileobj
        self.bufferstr=''
        super().__init__(initial_value=initial_value, newline=newline)

    def write(self, __s: str) -> int:
        # if self.bufferstr[-1]=='\n':
        #     self.fileobj.write(self.bufferstr)
        #     self.bufferstr=None
        #     self.fileobj
        self.bufferstr=self.bufferstr+__s
        return super().write(__s)

    def flush(self) -> None:
        if self.bufferstr != '':
            self.fileobj.write('flush was called .......:'+self.bufferstr)
            self.bufferstr=''
        return super().flush()

print('1rook runs')

stdout=checkmate(fileobj=fileout,initial_value=None,newline=None)
sys.stdout=stdout
stderr=checkmate(fileobj=fileerr,initial_value=None,newline=None)
sys.stderr=stderr

print('2queen misses',flush=True) 
print('3queen misses again')
warnings.warn('fake warning')
a,b=0,3
print('6queen misses again')
print(b/a)